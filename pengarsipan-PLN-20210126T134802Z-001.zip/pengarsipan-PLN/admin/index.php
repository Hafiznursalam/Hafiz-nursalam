<?php
  session_start();
  include"koneksi.php";
  if(empty($_SESSION['admin'])){
  header("location:login.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="css/dataTables.bootstrap.css"/>
    <title> PT PLN UIP SUMBAGSEL</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/login.css"/>
	<link rel="stylesheet" type="text/css" href="../css/tema.css"/>
    <link rel="stylesheet" type="text/css" href="menu.css">

    <link href="css/freelancer.min.css" rel="stylesheet">
    <!-- Custom Fonts -->
    
</head>

<body id="page-top" class="index">

    <!-- Navigation -->
   <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
    <div class="container-fluid">
    <div class="navbar-header">
    <button type="button"  class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">toggle navigator</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <p class="navbar-brand"><img src="image/logo.png" ></p>
</div>
            <!-- Collect the nav links, forms, and other content for toggling -->
           <div class="collapse navbar-collapse" id="navbar">
    <ul class="nav navbar-nav navbar-right">
        <li>
            <a href="?p=beranda" class="active">
                <font color="#ffffff">
                    <span class="glyphicon glyphicon-home"></span>&nbsp;Beranda
                </font>
            </a>
        </li>
        <!-- awal dropdown -->
        <li class="dropdown" style="color: black;">
            <a href="" class="dropdown-toggle" data-target="dropdown" data-toggle="dropdown" id="al" role="button" aria-haspopup="true" aria-expanded="true">
                <font color="#ffffff">
                    <span class=" glyphicon glyphicon-book"></span> Data.Adm SDM
                </font>
                <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li> <a href="?p=biodata">Biodata Pegawai</a></li>
                <li><a href="?p=golongan2">Golongan</a></li>
                <li> <a href="?p=pensiun">Pensiun</a></li>
                <li> <a href="?p=pajak">Pajak</a></li>
                <li> <a href="?p=skpp">SKPP</a></li>
                <li> <a href="?p=bprp">BPRP</a></li>
                <li> <a href="?p=bpfp">BPFP</a></li>
                <li> <a href="?p=dplk">DPLK</a></li>
            </ul>
        </li>
       
        <li>
            <a href="?p=logout">
                <font color="#ffffff" onclick="return confirm('Apakah anda yakin akan keluar?')">Logout&nbsp;
                    <span class="glyphicon glyphicon-log-out "></span>
                </font>
            </a>
        </li>
                    
    </ul>
</div>
</div>
</nav>
    <section id="portfolio">
        <div class="container">
            <div class="row">
                <div class="jumbotron">
					<div class="container">
						<p align="center"><?php include"control/isi.php"; ?></p>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<footer class="footer">
	<div class="container">
		<p align="center"><font color="#000fff">&copy; 2016 PLN UIP SUMBAGSEL</font></p>
	</div>
</footer>
<!-- jQuery -->
    
    <script src="js/jquery-1.11.0.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="datatables/jquery.dataTables.js"></script>
        <script src="datatables/dataTables.bootstrap.js"></script>
        <script type="text/javascript">
            $(function(){
                $("#biodata,#golongan, #skpp, #pensiun, #pajak, #dplk, #bprp, #bpfp").dataTable();
            });
        </script>
   <script src="js/freelancer.min.js"></script>
    
</body>
</html>