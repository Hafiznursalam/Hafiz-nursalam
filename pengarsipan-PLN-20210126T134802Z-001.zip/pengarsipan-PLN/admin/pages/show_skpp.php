    <style type="text/css">
        a{
            font-size: 9pt;
            color: #fff;
        }
        .btn a{
            color: #fff;
        }
        th{
            text-align: center;
        }
    </style>
   <H3>SKPP</H3>
            <table id="skpp" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="7%">NIP</th>
                        <th width="12%">Nama Pegawai</th>
                        <th width="12%">Jabatan</th>
                        <th width="8%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    //Data mentah yang ditampilkan ke tabel    
                    $koneksi = mysqli_connect('localhost', 'root', '', "pengarsipan");
                    $sql = mysqli_query($koneksi, "SELECT * FROM biodata where jabatan='MUTASI UNIT' or 'Mutasi Unit' or 'mutasi unit' order by waktu desc");
                    if (mysqli_num_rows($sql) == 0){
                        echo "Gagal Menampilkan data";
                    }
                   
                    while ($r = mysqli_fetch_array($sql)) {
                    
                    ?>

                    <tr align='left'>
                        <td><?php echo  $r['nip'];?></td>
                        <td><?php echo  $r['nama_pegawai']; ?></td>
                        <td><?php echo  $r['jabatan']; ?></td>
                        <td align="center">
                            <a href="<?php echo 'pages/view2.php?p=tmpl_skpp&nip='.$r['nip'].'';?>"> 
                           <button class="btn btn-primary">View Data</button></a>
                            
                        </td>
                    </tr>
                    <?php
                    $no++;
                    }
                    ?>
                </tbody>
            </table>  
      
    