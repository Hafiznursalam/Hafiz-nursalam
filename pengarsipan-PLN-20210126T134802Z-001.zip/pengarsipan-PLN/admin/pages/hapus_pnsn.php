<?php
$data=mysql_fetch_array(mysql_query("SELECT * FROM pensiun where nmr='$_GET[nmr]'"));
mysql_query("DELETE FROM pensiun where nmr='$_GET[nmr]'")or die (mysql_error());
echo "data telah dihapus";
echo "<script>window.location.href='?p=tmpl_pensiun&nip=$data[nip]';</script>";
?>