<?php
session_start();
include "../koneksi.php";
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<!--untuk web responsive-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>PT PLN UIP SUMBAGSEL</title>
	<!--link pemanggilan scrip bootstrap-->
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/admin.css">

	<link rel="stylesheet" type="text/css" href="css/tema.css">
	<link rel="stylesheet" href="../css/dataTables.bootstrap.css"/>
	<style type="text/css">
	.navbar-brand img{
    margin-top: -12px;
    max-height: 60px;
}</style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<?php include "menu2.php"; ?>
	</div>
</nav>
<div class="container-fluid">
	<div class="row">
		<div class=" main">
			<?php include "../control/isi_sub2.php"; ?>
		
		</div>	
	</div>
</div>
<script src="../js/jquery-1.11.0.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../datatables/jquery.dataTables.js"></script>
        <script src="../datatables/dataTables.bootstrap.js"></script>
        <script type="text/javascript">
            $(function() {
                $("#pensiun, #pajak, #skpp, #bprp, #bpfp, #dplk").dataTable();
            });
        </script>
</body>
</html> 