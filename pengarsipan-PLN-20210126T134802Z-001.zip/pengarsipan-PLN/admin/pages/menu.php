<div class="navbar-header">
	<button type="button"  class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
		<span class="sr-only">toggle navigator</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
	<p class="navbar-brand"><img src="../image/logo.png" width="275px" height="50px"></p>
</div>

<div class="collapse navbar-collapse" id="navbar">
	<ul class="nav navbar-nav navbar-right">
		<li>
			<a href="../index.php?p=beranda" class="active">
				<font color="#ffffff">
					<span class="glyphicon glyphicon-home"></span>&nbsp;Beranda
				</font>
			</a>
		</li>
		<!-- awal dropdown -->
		<li class="dropdown" style="color: black;">
			<a href="" class="dropdown-toggle" data-target="dropdown" data-toggle="dropdown" id="al" role="button" aria-haspopup="true" aria-expanded="true">
				<font color="#ffffff">
					<span class=" glyphicon glyphicon-book"></span> Data.Adm SDM
				</font>
				<span class="caret"></span>
			</a>
			<ul class="dropdown-menu">
				<li> <a href="../index.php?p=biodata">Biodata Pegawai</a></li>
				<li> <a href="../index.php?p=golongan2">Golongan</a></li>
				<li> <a href="../index.php?p=pensiun">Pensiun</a></li>
				<li> <a href="../index.php?p=pajak">Pajak</a></li>
				<li> <a href="../index.php?p=skpp">SKPP</a></li>
				<li> <a href="../index.php?p=bprp">BPRP</a></li>
				<li> <a href="../index.php?p=bpfp">BPFP</a></li>
				<li> <a href="../index.php?p=dplk">DPLK</a></li>
			</ul>
		</li>
		
		<li>
			<a href="../index.php?p=logout">
			    <font color="#ffffff" onclick="return confirm('Apakah anda yakin akan keluar?')">Logout&nbsp;
			        <span class="glyphicon glyphicon-log-out "></span>
			    </font>
			</a>
		</li>
		<?php include"../control/isi.php"; ?>					
	</ul>
	<ul class="nav navbar-nav visible-xs" >
		<li><a href="?p=jabatan&nip=<?php echo $data['nip']; ?>">Jabatan</a></li>
		<li><a href="?p=golongan&nip=<?php echo $data['nip']; ?>">Golongan</a></li>
		<li><a href="?p=keluarga&nip=<?php echo $data['nip']; ?>">Keluarga</a></li>
		<li><a href="?p=lamaran&nip=<?php echo $data['nip']; ?>">Lamaran</a></li>
		<li><a href="?p=penghargaan&nip=<?php echo $data['nip']; ?>">Penghrg/hkm</a></li>
		<li><a href="?p=keterangan&nip=<?php echo $data['nip']; ?>">Ket.lain</a></li>
	</ul>
</div>