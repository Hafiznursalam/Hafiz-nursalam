<?php
error_reporting(0);
include"koneksi.php";
$data=mysql_fetch_array(mysql_query("select * from biodata where nip='$_GET[nip]'"));
?>
<style type="text/css">

form{
    max-width: 330px;
    padding: 15px;
    margin:15px auto;
    background-color: #fffffa;
    border: 1px solid black;
    border-radius: 10px ;
}
    </style>
<form method="post" action="" >
<h3 align="center">Edit Biodata</h3><br />
<div class="form-group">
    <label class="label-control"><i class="fa fa-number">NIP</i></label>
        <div class="col md-2">
          <input type="varchar"name="nip" required class="form-control" readonly value="<?php echo $data['nip']; ?>"/>
        </div>
</div>
<div class="form-group">
        <label class="label-control"><i class="fa fa-user">&nbsp;Nama Pegawai</i></label>
            <div class="col md-2">
                <input type="varchar" name="nama_pegawai" required class="form-control" value="<?php echo $data['nama_pegawai']; ?>"/>
            </div>
</div>
<div class="form-group">
        <label class="label-control"><i class="fa fa-carier">Jabatan</i></label>
            <div class="col md-2">
        <input type="varchar" name="jabatan" required class="form-control" value="<?php echo $data['jabatan']; ?>"/>
        </div>
</div>
<div class="form-group">
  
            <div class="col md-2">
           <input type="submit" name="simpan" value="simpan" class="btn btn-primary">
        </div>
</div>
</form>

<?php
error_reporting(0);
include"koneksi.php";
$nip=$_POST['nip'];
$nama_pegawai=$_POST['nama_pegawai'];
$jabatan=$_POST['jabatan'];
if (isset($_POST['simpan']))
{
	mysql_query("UPDATE biodata SET nip='$nip', nama_pegawai='$nama_pegawai', jabatan='$jabatan' where nip='$_GET[nip]'");
	echo"<script>alert('Data Berhasil di Edit');
	window.location='?p=biodata'</script>";
}
?>