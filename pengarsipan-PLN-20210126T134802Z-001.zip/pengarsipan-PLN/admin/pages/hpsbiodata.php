<?php
$data=mysql_fetch_array(mysql_query("SELECT * FROM biodata where nip='$_GET[nip]'"));
mysql_query("DELETE FROM biodata where nip='$_GET[nip]'")or die (mysql_error());
echo "data telah dihapus";
echo "<script>window.location.href='?p=biodata&nip=$data[nip]';</script>";
?>

//taruh di show_biodata.php//
<a href="?p=bio&nip=<?php echo $r['nip']; ?>" onclick="return confirm('Apakah anda yakin akan menghapus data ini?')"> <button class="btn btn-primary glyphicon glyphicon-trash" title="hapus"></button></a>


//taruh di isi.php//
elseif ($_GET['p']==bio)
	{ include"pages/hpsbiodata.php";
	}