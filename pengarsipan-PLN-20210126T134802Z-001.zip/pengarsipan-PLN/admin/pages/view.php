<?php
session_start();
include "../koneksi.php";
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
	<!--untuk web responsive-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>PT PLN UIP SUMBAGSEL</title>
	<!--link pemanggilan scrip bootstrap-->
	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/tema.css">
	<link rel="stylesheet" href="../css/dataTables.bootstrap.css"/>
	<style type="text/css">
	.navbar-brand img{
    margin-top: -10px;
    max-height: 60px;
}</style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<?php include "menu.php"; ?>
	</div>
</nav>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-2 col-sm-3 sidebar hidden-xs " style="background-color: rgba(27, 109, 133, 1);">
			<?php include"sidebar.php" ?>
		</div>
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
			<?php include "../control/isi_sub.php"; ?>
		</div>	
	</div>
</div>

<script src="../js/bootstrap.min.js"></script>
<script src="../../supervisor/js/jquery-3.1.1.min.js"></script>
<script src="../../supervisor/js/bootstrap.js"></script>
<script src="../datatables/jquery.dataTables.js"></script>
<script src="../datatables/dataTables.bootstrap.js"></script>
<script type="text/javascript">
  $(function() {
    $("#golongan, #jabatan, #keluarga, #lamaran, #penghargaan, #ket").dataTable();
    });
</script>
</body>
</html> 