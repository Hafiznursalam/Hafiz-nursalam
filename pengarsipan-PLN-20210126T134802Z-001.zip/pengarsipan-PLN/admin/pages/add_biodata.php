<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/form.css" />
    <style type="text/css">

form{
    max-width: 330px;
    padding: 15px;
    margin:15px auto;
    background-color: #fffffa;
    border: 1px solid black;
    border-radius: 10px ;
}
    </style>
</head>
<body>
</body>
<div id="isi"> 
<form method="post" action="" enctype="multipart/form-data">
<h2 align="center">Add Biodata</h2><br />
<div class="form-group">
    <label class="label-control"><i class="fa fa-number">NIP</i></label>
        <div class="col md-2">
		  <input type="varchar"name="nip" required class="form-control">
        </div>
</div>
<div class="form-group">
        <label class="label-control"><i class="fa fa-user">&nbsp;Nama Pegawai</i></label>
            <div class="col md-2">
                <input type="varchar"name="nama_pegawai" required class="form-control">
            </div>
</div>
<div class="form-group">
        <label class="label-control"><i class="fa fa-carier">Jabatan</i></label>
            <div class="col md-2">
        <input type="varchar" name="jabatan" required class="form-control">
        </div>
</div>
<div class="form-group">
  
            <div class="col md-2">
    	   <input type="submit" value="Kirim"name="kirim" class="btn btn-primary">
        </div>
</div>
    
    </form>
</div> 
<?php
error_reporting(0);
include"koneksi.php";

    $nip=$_POST['nip'];
    $nama_pegawai=$_POST['nama_pegawai'];
    $jabatan=$_POST['jabatan'];
    
    if(isset($nip)){
            // Cek nip di database
            $cek_nip=mysql_num_rows(mysql_query("SELECT nip FROM biodata WHERE nip='$_POST[nip]'"));
        if ($cek_nip > 0){
                // Kalau nip sudah ada
                echo"<script>alert('NIP sudah ada. Ulangi lagi'); 
                window.location='?p=add_biodata'</script>";
        }else{
                // Kalau nip valid, inputkan data ke tabel biodata
                $simpan=mysql_query("insert into biodata(nip,nama_pegawai,jabatan)
                value('$nip','$nama_pegawai','$jabatan')");
                echo"<script>alert ('Data Berhasil di simpan');
                window.location='?p=biodata'</script>";
            }
    }


?>   