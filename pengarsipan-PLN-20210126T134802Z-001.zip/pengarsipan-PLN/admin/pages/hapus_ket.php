<?php
$data=mysql_fetch_array(mysql_query("SELECT * FROM ket where nmr='$_GET[nmr]'"));
mysql_query("DELETE FROM ket where nmr='$_GET[nmr]'")or die (mysql_error());
echo "data telah dihapus";
echo "<script>window.location.href='?p=keterangan&nip=$data[nip]';</script>";
?>