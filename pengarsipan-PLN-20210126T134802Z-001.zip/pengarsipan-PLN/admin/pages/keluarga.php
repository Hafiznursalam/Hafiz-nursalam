    <style type="text/css">
        
        .btn a{
            color: #fff;
        }
        th{
            text-align: center;
        }
    </style>
    <h3> KELUARGA</h3>    
    <a href="?p=add_keluarga&nip=<?php echo $_GET['nip']; ?>" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span>&nbsp;Add Data</a><br><br>  
    <div class="table-responsive"></div>
            <table id="keluarga" class="table table-bordered">
                <thead>
                    <tr style="background-color: rgba(223, 240, 216, 1);">
                         <th width="7%">NIP</th>
                        <th width="8%">Nama Pegawai</th>
                        <th width="8%">Keterangan</th>
                        <th width="8%">File</th>
                        <th width="8%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    //Data mentah yang ditampilkan ke tabel    
                    $koneksi = mysqli_connect('localhost', 'root', '', "pengarsipan");
                    $sql = mysqli_query($koneksi, "SELECT * FROM keluarga where nip='$_GET[nip]' order by waktu desc");
                    if (mysqli_num_rows($sql) == 0){
                        echo "Gagal Menampilkan data";
                    }
                  
                    while ($r = mysqli_fetch_array($sql)) {
                    $id = $r['id'];
                    ?>

                    <tr align='center'>
                        <td><?php echo  $r['nip'];?></td>
                        <td><?php echo  $r['nama_pegawai']; ?></td>
                        <td><?php echo  $r['ket']; ?></td>
                        <td><?php echo  $r['file_klg']; ?></td>
                        <td align="center">

                             <a href="?p=hapus_klg&nmr=<?php echo $r['nmr']; ?>" onclick="return confirm('Apakah anda yakin akan menghapus data ini?')"> <button class="btn btn-primary glyphicon glyphicon-trash" title="hapus"></button></a>
                             
                            <a href="<?php echo '../pages/uploads/keluarga/'.$r['file_klg'].''?>"><button class="btn btn-primary glyphicon glyphicon-folder-open" title="Tampil Data"></button></a>

                        </td>
                    </tr>
                    <?php
                    $no++;
                    }
                    ?>
                </tbody>
            </table>