<?php
$data=mysql_fetch_array(mysql_query("SELECT * FROM jabatan where nmr='$_GET[nmr]'"));
mysql_query("DELETE FROM jabatan where nmr='$_GET[nmr]'")or die (mysql_error());
echo "data telah dihapus";
echo "<script>window.location.href='?p=jabatan&nip=$data[nip]';</script>";
?>