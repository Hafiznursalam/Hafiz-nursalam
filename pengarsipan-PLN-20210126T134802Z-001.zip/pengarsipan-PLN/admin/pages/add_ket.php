<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/form.css" />
    <title>Form Keterangan Lainnya</title>
    <style type="text/css">

form{
	max-width: 330px;
	padding: 15px;
	margin:50px auto;
	background: #eed;
}
    </style>
</head>
<body>
</body>
<div id="isi"> 
<form method="post" action="" enctype="multipart/form-data">
<h2>Add Data Ket.Lain-lain</h2><br />

	<?php
		error_reporting(0);
		include_once"koneksi.php";
		$nomor=$_GET['nip'];
		$data=mysql_fetch_array(mysql_query("select nip,nama_pegawai from biodata where nip='$nomor'"));				
	?>
	<div class="form-group">
	<label class="label-control col-md-2">NIP</label>
		<div class="col md-2">
			<input type="varchar" name="nip" class="form-control" value="<?php echo $data['nip']; ?>" readonly></input>
		</div>
	</div>
	<div class="form-group">
		<label class="label-control col-md-6">Nama Pegawai</label>
			<div class="col md-2">
				<input type="varchar" class="form-control" name="nama_pegawai" value="<?php echo $data['nama_pegawai']; ?>" readonly></input>
			</div>
	</div>
	<div class="form-group">
		<label class="label-control col-md-4">Keterangan</label>
			<div class="col md-2">
				<textarea rows="5" name="ket" class="form-control"></textarea>
			</div>
	</div>
	<div class="form-group">
		<label class="label-control col-md-4">Pilih File</label>
			<div class="col md-2">
				<input type="file" id="filenya" name="file_ket" required></input>
			</div>
	</div>
	<div class="form-group">		
		<input type="submit" value="kirim" name="kirim" class="btn btn-primary"></input>
	</div>
    </form>
</div>

<?php
error_reporting(0);
include_once 'koneksi.php';
if(isset($_POST['kirim']))
{    
    $nip = $_POST['nip'];
	$nama_pegawai = $_POST['nama_pegawai'];
	$ket = $_POST['ket'];
	$file_ket = rand(1000,100000)."-".$_FILES['file_ket']['name'];
    $file_ket_loc = $_FILES['file_ket']['tmp_name'];
	$folder="uploads/ket/";	
	
	// make file name in lower case
	$new_file_name = strtolower($file_ket);
	// make file name in lower case
	
	$final_file=$new_file_name;
	
	if(move_uploaded_file($file_ket_loc,$folder.$final_file))
	{
		$sql="INSERT INTO ket(nip,nama_pegawai,ket,file_ket) VALUES('$nip','$nama_pegawai','$ket','$file_ket')";
		mysql_query($sql);
		?>
		<script>
		alert('successfully uploaded');
        window.location.href='view.php?p=keterangan&nip=<?php echo $data['nip']; ?>';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while uploading file');
        window.location.href='add_ket.php?fail';
        </script>
		<?php
	}
}
?> 