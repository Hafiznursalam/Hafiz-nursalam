
<?php
				error_reporting(0);
				include_once"koneksi.php";
				$nomor=$_GET['nip'];
				$data=mysql_fetch_array(mysql_query("select nip from biodata where nip='$nomor'"));

				
			?>
			<style type="text/css">
			a{
				color: white;
			}
			</style>
<ul class="nav nav-sidebar ">
	<p class="list-group-item"><b> DATA</b></p>
	<li><a href="?p=jabatan&nip=<?php echo $data['nip']; ?>">Jabatan</a></li>
	<li><a href="?p=golongan&nip=<?php echo $data['nip']; ?>">Golongan</a></li>
	<li><a href="?p=keluarga&nip=<?php echo $data['nip']; ?>">Keluarga</a></li>
	<li><a href="?p=lamaran&nip=<?php echo $data['nip']; ?>">Lamaran</a></li>
	<li><a href="?p=penghargaan&nip=<?php echo $data['nip']; ?>">Penghrg/hkm</a></li>
	<li><a href="?p=keterangan&nip=<?php echo $data['nip']; ?>">Keterangan.lain</a></li>
</ul>