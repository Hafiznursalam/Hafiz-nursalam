
    <style type="text/css">
        a{
            font-size: 9pt;
            color: #fff;
        }
        .btn a{
            color: #fff;
        }
        th{
            text-align: center;
        }
    </style>
    <body>
    <h3>BIODATA</h3>
        <div class="container">
        <a href="?p=add_biodata"><button id="tombol" class="btn btn-primary">Add Data</button></a> </br></br>
            <table id="biodata" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="1%">No</th>
                        <th width="7%">NIP</th>
                        <th width="12%">Nama Pegawai</th>
                        <th width="12%">Jabatan</th>
                        <th width="8%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    //Data mentah yang ditampilkan ke tabel    
                    $koneksi = mysqli_connect('localhost', 'root', '', "pengarsipan");
                    $sql = mysqli_query($koneksi, "SELECT * FROM biodata order by waktu desc");
                    if (mysqli_num_rows($sql) == 0){
                        echo "Gagal Menampilkan data";
                    }
                    $no = 1;
                    while ($r = mysqli_fetch_array($sql)) {
                   
                    ?>

                    <tr>
                        <td align="center"><?php echo  $no;?></td>
                        <td><?php echo  $r['nip'];?></td>
                        <td><?php echo  $r['nama_pegawai']; ?></td>
                        <td><?php echo  $r['jabatan']; ?></td>
                        <td align="center">
                            <a href="<?php echo 'index.php?p=edit&nip='.$r['nip'].'';?>"><button class="btn btn-primary">
                                edit
                            </button></a>
                            <a href="<?php echo 'pages/view.php?nip='.$r['nip'].'';?>"><button class="btn btn-primary">View Biodata
                            </button></a>
                            
                        </td>
                    </tr>
                    <?php
                    $no++;
                    }
                    ?>
                </tbody>
            </table> 
        </div>
    