<?php
$data=mysql_fetch_array(mysql_query("SELECT * FROM dplk where nmr='$_GET[nmr]'"));
mysql_query("DELETE FROM dplk where nmr='$_GET[nmr]'")or die (mysql_error());
echo "data telah dihapus";
echo "<script>window.location.href='?p=tmpl_dplk&nip=$data[nip]';</script>";
?>