<body id="page-top" class="index" >
<div class="container">
    <img src="image/gg.jpg" width="100%" height="420px">
</div>
    <br>
    <div id="gtco-features" class="border-bottom">
        <div class="gtco-container">
            <div class="row">
               <div class="col-md-2 col-md-offset-5 text-center gtco-heading animate-box">
               <div class="thumbnail">
                    <a href="?p=biodata">
                    <img src="img/portfolio/biodata.png" width="50%" height="50%">
                    <p><font size="3,5pt"> Biodata Pegawai</font></p>
                    </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=pensiun">
                            <img src="img/portfolio/pensiun.png" width="50%" height="50%">
                        <p>Pensiun</p>
                        </a>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=pajak">
                    <img src="img/portfolio/pajak.png" width="50%" height="50%">
                    <p>Pajak</p>
                    </a>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=skpp">
                    <img src="img/portfolio/skpp.png" width="50%" height="50%">
                    <p>SKPP</p>
                    </a>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=bprp">
                    <img src="img/portfolio/bprp.png" width="50%" height="50%">
                    <p>BPRP</p>
                    </a>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=bpfp">
                    <img src="img/portfolio/bpfp.png" width="50%" height="50%">
                    <p>BPFP</p>
                    </a>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6" align="center">
                    <div class="thumbnail">
                        <a href="?p=dplk">
                    <img src="img/portfolio/dplk.png" width="50%" height="50%">
                    <p>DPLK</p>
                    </a>
                   </div> 
                </div>
                

            </div>
        </div>
    </div>

</body>