<?php
error_reporting(0);
if ($_GET['p']==tmpl_pajak)
	{ include"tmpl_pajak.php";
	}
elseif ($_GET['p']==add_pensiun)
	{ include"add_pensiun.php";
	}
elseif ($_GET['p']==tmpl_pensiun)
	{ include"tmpl_pensiun.php";
	}
elseif ($_GET['p']==hapus_dplk)
	{ include"hapus_dplk.php";
	}
elseif ($_GET['p']==hapus_pjk)
	{ include"hapus_pjk.php";
	}
elseif ($_GET['p']==hapus_pnsn)
	{ include"hapus_pnsn.php";
	}
elseif ($_GET['p']==add_pajak)
	{ include"add_pajak.php";
	}
elseif ($_GET['p']==add_skpp)
	{ include"add_skpp.php";
	}
elseif ($_GET['p']==tmpl_skpp)
	{ include"tmpl_skpp.php";
	}
elseif ($_GET['p']==hapus_skpp)
	{ include"hapus_skpp.php";
	}
elseif ($_GET['p']==tmpl_bprp)
	{ include"tmpl_bprp.php";
	}
elseif ($_GET['p']==add_bprp)
	{ include"add_bprp.php";
	}
elseif ($_GET['p']==tmpl_bpfp)
	{ include"tmpl_bpfp.php";
	}
elseif ($_GET['p']==hapus_bpfp)
	{ include"hapus_bpfp.php";
	}
elseif ($_GET['p']==hapus_bprp)
	{ include"hapus_bprp.php";
	}
elseif ($_GET['p']==add_bpfp)
	{ include"add_bpfp.php";
	}
elseif ($_GET['p']==tmpl_dplk)
	{ include"tmpl_dplk.php";
	}
elseif ($_GET['p']==add_dplk)
	{ include"add_dplk.php";
	}
else
	{ include"tmpl_pensiun.php";
	}

?>