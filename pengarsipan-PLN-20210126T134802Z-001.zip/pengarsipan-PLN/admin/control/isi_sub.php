<?php
error_reporting(0);
if ($_GET['p']==jabatan)
	{ include"jabatan.php";
	}
elseif ($_GET['p']==golongan)
	{ include"golongan.php";
	}
elseif ($_GET['p']==keluarga)
	{ include"keluarga.php";
	}
elseif ($_GET['p']==add_keluarga)
	{ include"add_keluarga.php";
	}
elseif ($_GET['p']==hapus_klg)
	{ include"hapus_klg.php";
	}
elseif ($_GET['p']==lamaran)
	{ include"lamaran.php";
	}
elseif ($_GET['p']==hapus_lmr)
	{ include"hapus_lmr.php";
	}
elseif ($_GET['p']==penghargaan)
	{ include"penghrg.php";
	}
elseif ($_GET['p']==hapus_pghrg)
	{ include"hapus_pghrg.php";
	}
elseif ($_GET['p']==phrg)
	{ include"add_phrg.php";
	}
elseif ($_GET['p']==keterangan)
	{ include"keterangan.php";
	}
elseif ($_GET['p']==hapus_ket)
	{ include"hapus_ket.php";
	}
elseif ($_GET['p']==ket)
	{ include"add_ket.php";
	}
elseif ($_GET['p']==gol)
	{
		include"add_gol.php";
	}
elseif ($_GET['p']==hapus_jbt)
	{
		include"hapus_jbt.php";
	}
elseif ($_GET['p']==jbt)
	{
		include"add_jbt.php";
	}
elseif ($_GET['p']==add_lamaran)
	{
		include"add_lamaran.php";
	}
elseif ($_GET['p']==hapus)
	{
		include"hapus.php";
	}
elseif ($_GET['p']==tambah_proses)
	{
		include"menu_tambah_proses.php";
	}
else
	{ include"jabatan.php";
	}

?>