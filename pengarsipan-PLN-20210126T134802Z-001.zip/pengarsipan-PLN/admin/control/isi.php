<?php
error_reporting(0);
if ($_GET['p']==biodata)
	{ include"pages/show_biodata.php";
	}
elseif ($_GET['p']==golongan2)
	{ include"pages/golongan2.php";
	}
elseif ($_GET['p']==hpsgolongan2)
	{ include"pages/hpsgolongan2.php";
	}	
elseif ($_GET['p']==pensiun)
	{ include"pages/show_pensiun.php";
	}
elseif ($_GET['p']==pajak)
	{ include"pages/show_pajak.php";
	}
elseif ($_GET['p']==skpp)
	{ include"pages/show_skpp.php";
	}
elseif ($_GET['p']==bprp)
	{ include"pages/show_bprp.php";
	}
elseif ($_GET['p']==bpfp)
	{ include"pages/show_bpfp.php";
	}
elseif ($_GET['p']==dplk)
	{ include"pages/show_dplk.php";
	}
	
elseif ($_GET['p']==logout)
	{ include"pages/logout.php";
	}
elseif ($_get['p']==view)
	{ include "pages/view.php";
	}
elseif ($_GET['p']==edit)
	{ include"pages/edit.php";
	}
elseif ($_GET['p']==add_biodata)
	{ include "pages/add_biodata.php";}
else
	{ include"pages/beranda.php";
	}

?>