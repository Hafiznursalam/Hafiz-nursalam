<?php
  session_start();
  error_reporting(0);
  include"koneksi.php";
  
  if(@$_SESSION['admin']){
	  header("location:index.php");
  }else if(@$_SESSION['supervisor']){
	  header("location:../supervisor/index.php");
  }else{
  	
?>
<!DOCTYPE html>
<html>
<head>
	<!--untuk web responsive-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>halaman bootstrap pertama</title>
	<!--link pemanggilan scrip bootstrap-->
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/login.css"/>
	<link rel="stylesheet" type="text/css" href="css/tema.css"/>
</head>
<body>
<div class="row-sm-12">
<nav class="navbar navbar-static-top">
<div class="col-md-2 col-left">
	<div class="container" >
		<div class="navbar-header">
			<img class="img-responsive" width="35%" height="60%" src="image/logo.png">
		</div>
	</div>
</div>
</nav>
<div class="col-sm-12 col-md-4 col-center">
<div class="jumbotron"  >
<h2 align="center">LOGIN</h2>
	<div class="container-fluid">
		
				<div class="form-login">
					<div class="panel panel-primary">
			   			<div class="panel-body">
				  		<form method="post" action="" class="form-horizontal">
							<div class="input-group">
								<div class="input-group-addon"><i class="glyphicon glyphicon-user"></i></div>
								<input type="varchar" name="username" placeholder="Username" autofocus class="form-control">
							</div>
							<br/>
							<div class="input-group">
								<div class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></div>
								<input type="password" name="password" placeholder="Password" class="form-control">
						</div>
							<br/>
							<input type="submit" name="login" value="Login" class="btn btn-primary pull-right">
							
				  			</form>	
				  			<?php
							$username = $_POST['username'];
							$password = $_POST['password'];
							$login = $_POST['login'];
							
							if($login){
								if($username == "" || $password == ""){
									?><script type="text/javascript">alert("Username / Password Tidak Boleh Kosong");</script><?php
								} else{
									$sql = mysql_query("select * from login where username = '$username'  and password= '$password'") or die (mysql_error());
									$data = mysql_fetch_array($sql);
									$cek = mysql_num_rows($sql);
									if($cek >= 1){
										if($data['level'] == "admin"){
											$_SESSION['admin'] = $data['kode_user'];
											header("location:index.php");
											
										}else if($data['level'] == "supervisor"){
											$_SESSION['supervisor'] = $data['kode_user'];
											header("location:../supervisor/index.php");
										}
									}else{echo "<script>alert('anda gagal login');
		window.location='login.php'</script>";
										
									}
								}
							}
							?>				  			
			   			</div>
					</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<footer class="footer">
	<div class="container">
		<p align="center">&copy; <b><?php echo date("Y"); ?> PLN UIP SUMBAGSEL.COM</b></p>
	</div>
</footer>

</body>
</html>
<?php
	}
?>