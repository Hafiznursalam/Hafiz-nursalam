<?php
include "koneksi.php";
require('fpdf/fpdf/fpdf.php');
/**
 Judul  : Laporan PDF (portait):
 Level  : Menengah
 Author : Hakko Bio Richard
 Blog   : www.hakkoblogs.com
 Web    : www.niqoweb.com
 Email  : hakkobiorichard@ygmail.com
 
 Untuk tutorial yang lainnya silahkan berkunjung ke www.hakkoblogs.com
 
 Butuh jasa pembuatan website, aplikasi, pembuatan program TA dan Skripsi.? Hubungi NiqoWeb ==>> 085694984803
 
 **/
//Menampilkan data dari tabel di database


$result=mysql_query("select * from jabatan where waktu>='$_GET[awal]' AND waktu <= '
$_GET[akhir]' order by waktu desc") or die(mysql_error());

//Inisiasi untuk membuat header kolom
$column_nip = "";
$column_nama_pegawai = "";
$column_ket = "";
$column_file_jbt = "";

//For each row, add the field to the corresponding column
while($row = mysql_fetch_array($result))
{
	
    $nip = $row["nip"];
    $nama_pegawai = $row["nama_pegawai"];
    $ket = $row["ket"];
    $file_jbt = $row["file_jbt"];
 
    

    $column_nip = $column_nip.$nip."\n";
    $column_nama_pegawai = $column_nama_pegawai.$nama_pegawai."\n";
    $column_ket = $column_ket.$ket."\n";
    $column_file_jbt = $column_file_jbt.$file_jbt."\n";
}

//Create a new PDF file
$pdf = new FPDF('P','mm',array(210,297)); //L For Landscape / P For Portrait
$pdf->AddPage();

//Menambahkan Gambar
$pdf->Image('lg1.png',10,3);

$pdf->SetFont('Arial','B',13);
$pdf->Cell(80);
$pdf->Cell(30,10,'DATA Administrasi SDM',0,0,'C');
$pdf->Ln();
$pdf->Cell(80);
$pdf->Cell(30,10,'PT. PLN (Persero) UIP Sumbagsel',0,0,'C');
$pdf->Ln();


//Fields Name position
$Y_Fields_Name_position = 30;

//First create each Field Name
//Gray color filling each Field Name box
$pdf->SetFillColor(110,180,230);
//Bold Font for Field Name
$pdf->SetFont('Arial','B',10);
$pdf->SetY($Y_Fields_Name_position);
$pdf->SetX(5);
$pdf->Cell(35,8,'NIP',1,0,'C',1);
$pdf->SetX(40);
$pdf->Cell(60,8,'Nama Pegawai',1,0,'C',1);
$pdf->SetX(100);
$pdf->Cell(50,8,'Keterangan',1,0,'C',1);
$pdf->SetX(150);
$pdf->Cell(50,8,'File',1,4,'C',1);
$pdf->Ln();


//Table position, under Fields Name
$Y_Table_Position = 38;

//Now show the columns
$pdf->SetFont('Arial','',8);

$pdf->SetY($Y_Table_Position);
$pdf->SetX(5);
$pdf->MultiCell(35,6,$column_nip,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(40);
$pdf->MultiCell(60,6,$column_nama_pegawai,1,'L');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(100);
$pdf->MultiCell(50,6,$column_ket,1,'C');

$pdf->SetY($Y_Table_Position);
$pdf->SetX(150);
$pdf->MultiCell(50,6,$column_file_jbt,1,'L');
	
$pdf->Output();
?>
