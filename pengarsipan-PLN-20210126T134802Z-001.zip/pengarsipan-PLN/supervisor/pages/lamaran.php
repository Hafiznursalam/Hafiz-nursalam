<?php
include "koneksi.php"; // menghubungkan ke file koneksi.php agar terhubung dengan database
?>

<!DOCTYPE html>
<html>
<head>
 <title>Lihat Data</title>
<!-- CSS untuk mempercantik tampilan-->
   

</head>

<body>

<legend>
  <h1>Biodata Pegawai</h1>
  <h4>Lamaran</h4>
</legend>
 <div align="right">
  <form action="" method="post">
   <input type="text" name="input_awal" placeholder="YYYY-MM-DD" class="css-input" style="width:100px;" />
   <input type="text" name="input_akhir" placeholder="YYYY-MM-DD" class="css-input" style="width:100px;" />
   <button type="submit" name="cari" value="Cetak" class="btn btn-primary" style="padding:3px; width:30px;" title="Cetak"><span class="glyphicon glyphicon-print"></span></button>
   <table id="biodata" class="table table-bordered table-striped">
   <thead>
     <tr style="background: rgba(178, 219, 161, 1);">
         <th align="center">NIP</th>
         <th>Nama Pegawai</th>
         <th>Keterangan</th>
         <th width="30%">File</th>
     </tr>
  </thead>
     <?php 

   $input_awal = @$_POST['input_awal'];
   $input_akhir = @$_POST['input_akhir']; 
   $cari = @$_POST['cari'];

   // jika tombol cari di klik
   if($cari) {

    // jika kotak pencarian tidak sama dengan kosong
    if(($input_awal != "") AND ($input_akhir != "")) {
    // query mysql untuk mencari berdasarkan waktu
    $sql = mysql_query("select * from lamaran where waktu >= '$input_awal' AND waktu <= '
	$input_akhir' order by waktu desc") or die (mysql_error());echo " <script>window.location='pages/cetaklmr1.php?awal=$input_awal&akhir=$input_akhir'</script>";   
    } else {
    $sql = mysql_query("select * from lamaran where waktu>='$_GET[tgl]' order by waktu desc") or die (mysql_error());
	echo " <script>window.location='pages/cetaklmr.php?tgl=$_GET[tgl]'</script>"; 
    }
    } else {
    $sql = mysql_query("select * from lamaran where waktu>='$_GET[tgl]' order by waktu desc") or die (mysql_error());
    }

   // mengecek data
   $cek = mysql_num_rows($sql);
   // jika data kurang dari 1
   if($cek < 1) {
    ?>
     <tr>
       <!--muncul peringata bahwa data tidak di temukan-->
       <td colspan="7" align="center style="padding:10px;""> Data Tidak Ditemukan</td>
     </tr>
     <?php
   } else {

   // mengulangi data agar tidak hanya 1 yang tampil
   while($data = mysql_fetch_array($sql)) {

   ?>
     <tr>
       <td><?php echo  $data['nip'];?></td>
                        <td><?php echo  $data['nama_pegawai']; ?></td>
                        <td><?php echo  $data['ket']; ?></td>
                        <td><?php echo  $data['file_lmr']; ?></td>
       
     </tr>
     <?php 

  } 
 }
?>
   </table>
   
  </form>
 </div>
<br><br>
</body>
</html>