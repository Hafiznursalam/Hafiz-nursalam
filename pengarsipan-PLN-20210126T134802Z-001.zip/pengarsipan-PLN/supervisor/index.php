<?php
  session_start();
  include"koneksi.php";
  if(empty($_SESSION['supervisor'])){
  header("location:../admin/login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/tema.css">
</head>
<body style="margin-top: 40px; background: #eee; "> 
<!-- navbar -->
	<nav class="navbar navbar-inverse navbar-fixed-top" >
		<div class="container-fluid"> 
			<div class="navbar-header">
				<button type="button"  class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">toggle navigator</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="color: #000; background-color: #fff;">V-ADMIN <?php
					$tgl=date('Y-m-d');
					echo $tgl; ?>
				</a>
			</div>

			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown" style="color: black;">
						<a href="" class="dropdown-toggle" data-target="dropdown" data-toggle="dropdown" id="al" role="button" aria-haspopup="true" aria-expanded="true">
							<font color="#ffffff">
								<span class=" glyphicon glyphicon-tasks"></span> Biodata Pegawai
							</font>
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
							<li><a href="?p=jabatan&tgl=<?php echo $tgl; ?>">Jabatan</a></li>
							<li><a href="?p=golongan&?tgl=<?php echo $tgl; ?>">Golongan</a></li>
							<li><a href="?p=keluarga&?tgl=<?php echo $tgl; ?>">Keluarga</a></li>
							<li><a href="?p=lamaran&?tgl=<?php echo $tgl; ?>">Lamaran</a></li>
							<li><a href="?p=penghargaan&?tgl=<?php echo $tgl; ?>">Penghargaan</a></li>
							<li><a href="?p=ket&?tgl=<?php echo $tgl; ?>">Keterangan Lain</a></li>
						</ul>
					</li>
					<li><a style="color: #fff;" href="?p=pensiun&?tgl=<?php echo $tgl; ?>"><span class="glyphicon glyphicon-user"></span> Pensiun</a></li>
					<li><a style="color: #fff;" href="?p=pajak&?tgl=<?php echo $tgl; ?>">Pajak</a></li>
					<li><a style="color: #fff;" href="?p=skpp&?tgl=<?php echo $tgl; ?>">SKPP</a></li>
					<li><a style="color: #fff;" href="?p=bprp&?tgl=<?php echo $tgl; ?>">BPRP</a></li>
					<li><a style="color: #fff;" href="?p=bpfp&?tgl=<?php echo $tgl; ?>">BPFP</a></li>
					<li><a style="color: #fff;" href="?p=dplk&?tgl=<?php echo $tgl; ?>">DPLK</a></li>
					
					<li><a style="color: #fff;" href="logout.php" onclick="return confirm('Apakah anda yakin akan keluar?')">Logout <span class="glyphicon glyphicon-log-out "></span></a></li>
				</ul>
			</div>
		</div>
	</nav>
<!-- akhir navbar -->
<div class="container" style="background: #fff; ">
	<?php include"control/isi_sub.php"; ?>				
</div>
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>