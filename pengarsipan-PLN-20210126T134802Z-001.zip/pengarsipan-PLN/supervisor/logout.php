<?php
session_start(); //perintah agar file ini membaca/mengenal/memulai session
unset($_SESSION['supervisor']); // perintah menghapus semua session yg ada

?>
		<script>// mengalihkan halaman ke login.php
		
        window.location.href='index.php?fail';
        </script>