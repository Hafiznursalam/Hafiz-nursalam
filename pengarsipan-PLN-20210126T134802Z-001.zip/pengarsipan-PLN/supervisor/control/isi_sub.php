<?php
error_reporting(0);
if ($_GET['p']==jabatan)
	{ include"pages/jabatan.php";
	}
elseif ($_GET['p']==golongan)
	{ include"pages/golongan.php";
	}
elseif ($_GET['p']==keluarga)
	{ include"pages/keluarga.php";
	}
elseif ($_GET['p']==lamaran)
	{ include"pages/lamaran.php";
	}
elseif ($_GET['p']==penghargaan)
	{ include"pages/penghargaan.php";
	}
elseif ($_GET['p']==ket)
	{ include"pages/ket.php";
	}
elseif ($_GET['p']==pensiun)
	{ include"pages/pensiun.php";
	}
elseif ($_GET['p']==pajak)
	{ include"pages/pajak.php";
	}
elseif ($_GET['p']==skpp)
	{ include"pages/skpp.php";
	}
elseif ($_GET['p']==bprp)
	{ include"pages/bprp.php";
	}
elseif ($_GET['p']==bpfp)
	{ include"pages/bpfp.php";
	}
elseif ($_GET['p']==dplk)
	{ include"pages/dplk.php";
	}
else
	{ include"pages/jabatan.php";
	}

?>